gnuradio.blocks: Peak Detectors
===============================

.. autoblock:: gnuradio.blocks.peak_detector_fb
.. autoblock:: gnuradio.blocks.peak_detector_ib
.. autoblock:: gnuradio.blocks.peak_detector_sb
.. autoblock:: gnuradio.blocks.burst_tagger
.. autoblock:: gnuradio.blocks.peak_detector2_fb
.. autoblock:: gnuradio.blocks.plateau_detector_fb