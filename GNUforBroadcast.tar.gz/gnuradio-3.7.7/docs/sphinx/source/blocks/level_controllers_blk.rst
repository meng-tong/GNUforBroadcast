gnuradio.blocks: Level Controllers
==================================

.. autoblock:: gnuradio.blocks.moving_average_cc
.. autoblock:: gnuradio.blocks.moving_average_ff
.. autoblock:: gnuradio.blocks.moving_average_ii
.. autoblock:: gnuradio.blocks.moving_average_ss
.. autoblock:: gnuradio.blocks.mute_cc
.. autoblock:: gnuradio.blocks.mute_ff
.. autoblock:: gnuradio.blocks.mute_ii
.. autoblock:: gnuradio.blocks.mute_ss
.. autoblock:: gnuradio.blocks.sample_and_hold_bb
.. autoblock:: gnuradio.blocks.sample_and_hold_ff
.. autoblock:: gnuradio.blocks.sample_and_hold_ii
.. autoblock:: gnuradio.blocks.sample_and_hold_ss
.. autoblock:: gnuradio.blocks.threshold_ff