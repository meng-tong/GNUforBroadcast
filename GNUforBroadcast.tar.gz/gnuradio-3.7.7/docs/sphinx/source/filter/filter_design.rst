gnuradio.filter: Digital Filter Design
======================================

.. autoclass:: gnuradio.filter.firdes
