gnuradio.analog: Synchronizers
==============================

.. autoblock:: gnuradio.analog.pll_carriertracking_cc
.. autoblock:: gnuradio.analog.pll_freqdet_cf
.. autoblock:: gnuradio.analog.pll_refout_cc