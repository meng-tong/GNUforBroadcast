pmt: Read/Write
===============

.. autofunction:: pmt.is_eof_object
.. autofunction:: pmt.read
.. autofunction:: pmt.write
.. autofunction:: pmt.write_string
