pmt: Numbers
============

.. autofunction:: pmt.is_number
