pmt: Lists
==========

.. autofunction:: pmt.map
.. autofunction:: pmt.reverse
.. autofunction:: pmt.reverse_x
.. autofunction:: pmt.acons
.. autofunction:: pmt.nth
.. autofunction:: pmt.nthcdr
.. autofunction:: pmt.memq
.. autofunction:: pmt.memv
.. autofunction:: pmt.member
.. autofunction:: pmt.subsetp
.. autofunction:: pmt.list1
.. autofunction:: pmt.list2
.. autofunction:: pmt.list3
.. autofunction:: pmt.list4
.. autofunction:: pmt.list5
.. autofunction:: pmt.list6
.. autofunction:: pmt.list_add
.. autofunction:: pmt.list_rm
.. autofunction:: pmt.list_has
