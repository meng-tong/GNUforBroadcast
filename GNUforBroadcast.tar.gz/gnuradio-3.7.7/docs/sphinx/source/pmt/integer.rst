pmt: Integers
=============

.. autofunction:: pmt.is_integer
.. autofunction:: pmt.to_long
.. autofunction:: pmt.from_long


pmt: uint64_t
=============
.. autofunction:: pmt.is_uint64
.. autofunction:: pmt.to_uint64
.. autofunction:: pmt.from_uint64
