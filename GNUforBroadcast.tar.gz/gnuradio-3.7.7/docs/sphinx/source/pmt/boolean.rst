pmt: Booleans
=============

.. autofunction:: pmt.is_bool
.. autofunction:: pmt.is_true
.. autofunction:: pmt.is_false
.. autofunction:: pmt.from_bool
.. autofunction:: pmt.to_bool
