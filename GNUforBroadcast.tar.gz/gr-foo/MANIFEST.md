brief: some utility blocks
author:
  - Bastian Bloessl <bloessl@ccs-labs.org>
copyright_owner:
  - Bastian Bloessl
dependencies:
  - gnuradio (>= 3.7.4)
repo: https://github.com/bastibl/gr-foo.git
tags:
  - foo
website: https://github.com/bastibl/gr-foo
title: gr-foo
icon: http://www.ccs-labs.org/projects/wime/wime.png
---
This is a collection of custom blocks that are not directly associated with a project. For sample applications see:

https://github.com/bastibl/gr-ieee802-11
https://github.com/bastibl/gr-ieee802-15-4
