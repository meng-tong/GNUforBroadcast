gnuradio.blocks: Byte Operators
===============================

.. autoblock:: gnuradio.blocks.packed_to_unpacked_bb
.. autoblock:: gnuradio.blocks.packed_to_unpacked_ii
.. autoblock:: gnuradio.blocks.packed_to_unpacked_ss
.. autoblock:: gnuradio.blocks.unpacked_to_packed_bb
.. autoblock:: gnuradio.blocks.unpacked_to_packed_ii
.. autoblock:: gnuradio.blocks.unpacked_to_packed_ss
.. autoblock:: gnuradio.blocks.pack_k_bits_bb
.. autoblock:: gnuradio.blocks.repack_bits_bb
.. autoblock:: gnuradio.blocks.unpack_k_bits_bb