gnuradio.blocks: Audio Signals
==============================

.. autoblock:: gnuradio.blocks.wavfile_sink
.. autoblock:: gnuradio.blocks.wavfile_source