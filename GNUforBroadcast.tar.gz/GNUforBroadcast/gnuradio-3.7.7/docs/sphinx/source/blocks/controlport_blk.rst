gnuradio.blocks: ControlPort
============================

.. autoblock:: gnuradio.blocks.ctrlport_probe2_c
.. autoblock:: gnuradio.blocks.ctrlport_probe_c