gnuradio.vocoder
================

.. automodule:: gnuradio.vocoder

.. autosummary::
   :nosignatures:

   gnuradio.vocoder.alaw_decode_bs
   gnuradio.vocoder.alaw_encode_sb
   gnuradio.vocoder.codec2_decode_ps
   gnuradio.vocoder.codec2_encode_sp
   gnuradio.vocoder.cvsd_decode_bf
   gnuradio.vocoder.cvsd_decode_bs
   gnuradio.vocoder.cvsd_encode_fb
   gnuradio.vocoder.cvsd_encode_sb
   gnuradio.vocoder.g721_decode_bs
   gnuradio.vocoder.g721_encode_sb
   gnuradio.vocoder.g723_24_decode_bs
   gnuradio.vocoder.g723_24_encode_sb
   gnuradio.vocoder.g723_40_decode_bs
   gnuradio.vocoder.g723_40_encode_sb
   gnuradio.vocoder.gsm_fr_decode_ps
   gnuradio.vocoder.gsm_fr_encode_sp
   gnuradio.vocoder.ulaw_decode_bs
   gnuradio.vocoder.ulaw_encode_sb
