pmt: Serialize
==============

.. autofunction:: pmt.serialize
.. autofunction:: pmt.deserialize
.. autofunction:: pmt.dump_sizeof
.. autofunction:: pmt.serialize_str
.. autofunction:: pmt.deserialize_str
