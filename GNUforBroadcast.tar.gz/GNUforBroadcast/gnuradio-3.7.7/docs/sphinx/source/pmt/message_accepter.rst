pmt: Message Accepter
=====================

.. autofunction:: pmt.is_msg_accepter
.. autofunction:: pmt.make_msg_accepter
.. autofunction:: pmt.msg_accepter_ref

