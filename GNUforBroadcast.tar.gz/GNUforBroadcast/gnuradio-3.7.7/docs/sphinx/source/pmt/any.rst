pmt: Any
========

.. autofunction:: pmt.is_any
.. autofunction:: pmt.make_any
.. autofunction:: pmt.any_ref
.. autofunction:: pmt.any_set
