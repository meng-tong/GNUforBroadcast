pmt: BLOBs
==========

.. autofunction:: pmt.is_blob
.. autofunction:: pmt.make_blob
.. autofunction:: pmt.blob_data
.. autofunction:: pmt.blob_length
