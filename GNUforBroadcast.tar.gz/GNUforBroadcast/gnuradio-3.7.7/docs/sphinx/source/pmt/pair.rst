pmt: Pairs
==========

.. autofunction:: pmt.is_pair
.. autofunction:: pmt.cons
.. autofunction:: pmt.car
.. autofunction:: pmt.cdr
.. autofunction:: pmt.set_car
.. autofunction:: pmt.set_cdr
.. autofunction:: pmt.caar
.. autofunction:: pmt.cadddr
.. autofunction:: pmt.caddr
.. autofunction:: pmt.cadr
.. autofunction:: pmt.cdar
.. autofunction:: pmt.cddr
