pmt: General Functions
======================

   pmt.map
   pmt.reverse
   pmt.reverse_x
   pmt.acons
   pmt.nth
   pmt.nthcdr
   pmt.memq
   pmt.memv
   pmt.member
   pmt.subsetp
   pmt.list1
   pmt.list2
   pmt.list3
   pmt.list4
   pmt.list5
   pmt.list6
   pmt.list_add
   pmt.list_rm
   pmt.list_has

.. autofunction:: pmt.eq
.. autofunction:: pmt.equal
.. autofunction:: pmt.eqv
.. autofunction:: pmt.length
.. autofunction:: pmt.assq
.. autofunction:: pmt.assv
.. autofunction:: pmt.assoc

