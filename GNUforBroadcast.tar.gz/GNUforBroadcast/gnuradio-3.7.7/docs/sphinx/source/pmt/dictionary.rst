pmt: Dictionary
===============

.. autofunction:: pmt.is_dict
.. autofunction:: pmt.make_dict
.. autofunction:: pmt.dict_add
.. autofunction:: pmt.dict_delete
.. autofunction:: pmt.dict_has_key
.. autofunction:: pmt.dict_ref
.. autofunction:: pmt.dict_items
.. autofunction:: pmt.dict_keys
.. autofunction:: pmt.dict_values
