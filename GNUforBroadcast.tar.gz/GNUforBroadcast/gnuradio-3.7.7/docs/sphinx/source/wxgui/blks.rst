gnuradio.wxgui
=====================

.. autoblock:: gnuradio.wxgui.histo_sink_f
.. autoblock:: gnuradio.wxgui.oscope_sink_f

.. autopyblock:: gnuradio.wxgui.constsink_gl.const_sink_c
.. autopyblock:: gnuradio.wxgui.fftsink2.fft_sink_c
.. autopyblock:: gnuradio.wxgui.fftsink2.fft_sink_f
.. autopyblock:: gnuradio.wxgui.histosink_gl.histo_sink_f
.. autopyblock:: gnuradio.wxgui.numbersink2.number_sink_c
.. autopyblock:: gnuradio.wxgui.numbersink2.number_sink_f
.. autopyblock:: gnuradio.wxgui.scopesink2.scope_sink_c
.. autopyblock:: gnuradio.wxgui.scopesink2.scope_sink_f
.. autopyblock:: gnuradio.wxgui.waterfallsink2.waterfall_sink_c
.. autopyblock:: gnuradio.wxgui.waterfallsink2.waterfall_sink_f
