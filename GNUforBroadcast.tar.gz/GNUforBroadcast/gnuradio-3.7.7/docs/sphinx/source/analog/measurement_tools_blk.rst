gnuradio.analog: Measurement Tools
==================================

.. autoblock:: gnuradio.analog.probe_avg_mag_sqrd_c
.. autoblock:: gnuradio.analog.probe_avg_mag_sqrd_cf
.. autoblock:: gnuradio.analog.probe_avg_mag_sqrd_f