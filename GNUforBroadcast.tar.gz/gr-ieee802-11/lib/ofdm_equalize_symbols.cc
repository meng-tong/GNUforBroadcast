/*
 * Copyright (C) 2013 Bastian Bloessl <bloessl@ccs-labs.org>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <ieee802-11/ofdm_equalize_symbols.h>

#include "utils.h"
#include "equalizer/base.h"
#include "equalizer/linear_comb.h"
#include "equalizer/lms.h"
#include <gnuradio/io_signature.h>

using namespace gr::ieee802_11;

const float NOISE_AVG_RATE = 0.001;
const float SIGNAL_AVG_RATE = 0.05;

class ofdm_equalize_symbols_impl : public ofdm_equalize_symbols {

public:
ofdm_equalize_symbols_impl(Equalizer algo, bool debug) : block("ofdm_equalize_symbols",
			gr::io_signature::make(1, 1, 64 * sizeof(gr_complex)),
			gr::io_signature::make(1, 1, 48 * sizeof(gr_complex))),
			d_debug(debug), d_equalizer(NULL),
			d_npkt(0), d_noise_mag2(0) {

	set_relative_rate(1);
	set_tag_propagation_policy(block::TPP_DONT);
	set_algorithm(algo);
	
	d_signal_mag2 = (float*)calloc(64, sizeof(float));
}

~ofdm_equalize_symbols_impl(){
	free(d_signal_mag2);
}

int general_work (int noutput_items, gr_vector_int& ninput_items,
		gr_vector_const_void_star& input_items,
		gr_vector_void_star& output_items) {

	gr::thread::scoped_lock lock(d_mutex);

	const gr_complex *in = (const gr_complex*)input_items[0];
	gr_complex *out = (gr_complex*)output_items[0];

	int i = 0;
	int o = 0;

	dout << "SYMBOLS: input " << ninput_items[0] << "  output " << noutput_items << std::endl;
	
	// for noise level computation
	if(nitems_read(0) < NOISE_CALC_SYMBOL) {
		int non = 0;
		while(non<ninput_items[0]) {
			for(int k=6;k<=58;++k) {
				if(k==12 || k==25 || k==32 || k==39 || k==53) {continue;}
				//d_noise_mag2 += (abs(in[k]) * abs(in[k]));
				d_noise_mag2 = (1-NOISE_AVG_RATE)*d_noise_mag2 + NOISE_AVG_RATE*(abs(in[k])*abs(in[k]));
			}
			//if(non+nitems_read(0)>30 && non+nitems_read(0)<40) {std::cout<<in[30]<<std::endl;}
			non++;
			in += 64;
			
			if(nitems_read(0)+non == NOISE_CALC_SYMBOL) {
				//d_noise_mag2 /= (NOISE_CALC_SYMBOL*48.0);
				std::cout<<"Noise: "<<d_noise_mag2<<std::endl;
				break;
			}
		}
		
		consume(0, non);
		return 0;
	}

	while((i < ninput_items[0]) && (o < noutput_items)) {

		get_tags_in_window(tags, 0, i, i + 1, pmt::string_to_symbol("ofdm_start"));

		// new WiFi frame
		if(tags.size()) {
			d_nsym = 0;
			
			d_npkt++;
		}
		
		// first data symbol (= signal field)
		if(d_nsym == 2) {
			add_item_tag(0, nitems_written(0) + o,
				pmt::string_to_symbol("ofdm_start"),
				pmt::PMT_T,
				pmt::string_to_symbol(name()));
			
			if(d_npkt % 10 == 0) {
				//TODO: add encoding determination mechanism and encoding-carrier mapping
				add_item_tag(0, nitems_written(0) + o,
					pmt::string_to_symbol("subcarrier"),
					pmt::from_long(36),
					pmt::string_to_symbol(name()));
				/*std::cout<<"============encoding============="<<std::endl;
				float snrtmp = 0.0;
				for(int k=6;k<=58;++k) {
					if(k==12 || k==25 || k==32 || k==39 || k==53) {continue;}
					snrtmp = log10( (d_signal_mag2[k]-d_noise_mag2) / d_noise_mag2 );
					std::cout<<" "<<snrtmp<<std::endl;
				}*/
				
				if(d_npkt > 10) {d_npkt -= 10;}
			}
		}

		d_equalizer->equalize(in + (i * 64), out + (o * 48), d_nsym);

		if(d_nsym > 1) {
			o++;
		} else if(d_npkt <= 10) {
			float mtmp = 0;
			for(int k=6;k<=58;++k) {
				if(k==12 || k==25 || k==32 || k==39 || k==53) {continue;}
				mtmp = SIGNAL_AVG_RATE * abs(in[i*64+k]) * abs(in[i*64+k]);
				d_signal_mag2[k] += mtmp;
			}
		} else {
			float mtmp = 0;
			for(int k=6;k<=58;++k) {
				if(k==12 || k==25 || k==32 || k==39 || k==53) {continue;}
				mtmp = SIGNAL_AVG_RATE * abs(in[i*64+k]) * abs(in[i*64+k]);
				d_signal_mag2[k] = (1-SIGNAL_AVG_RATE)*d_signal_mag2[k] + mtmp;
			}
		}
		
		i++;
		d_nsym++;
	}

	dout << "SYMBOLS: consumed " << i << "  produced " << o << std::endl;

	consume(0, i);
	return o;
}

void set_algorithm(Equalizer algo) {
	gr::thread::scoped_lock lock(d_mutex);
	delete d_equalizer;

	switch(algo) {
	case LMS:
		dout << "LMS" << std::endl;
		d_equalizer = new equalizer::lms();
		break;

	case LINEAR_COMB:
		dout << "Linear Comb" << std::endl;
		d_equalizer = new equalizer::linear_comb();
		break;
	}
}

private:
	int			 d_npkt;
	float		 d_noise_mag2;
	float*		 d_signal_mag2;
	
	int          d_nsym;
	const bool   d_debug;
	equalizer::base *d_equalizer;
	std::vector<gr::tag_t> tags;
	gr::thread::mutex d_mutex;
};


ofdm_equalize_symbols::sptr
ofdm_equalize_symbols::make(Equalizer algo, bool debug) {
	return gnuradio::get_initial_sptr(new ofdm_equalize_symbols_impl(algo, debug));
}

