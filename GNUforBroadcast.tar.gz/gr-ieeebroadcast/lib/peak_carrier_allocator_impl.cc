/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "peak_carrier_allocator_impl.h"

#include "utils.h"

namespace gr {
  namespace ieeebroadcast {

    peak_carrier_allocator::sptr
    peak_carrier_allocator::make(const std::string &len_tag_key, bool log)
    {
      return gnuradio::get_initial_sptr
        (new peak_carrier_allocator_impl(len_tag_key, log));
    }

    peak_carrier_allocator_impl::peak_carrier_allocator_impl(const std::string &len_tag_key, bool log)
      : gr::tagged_stream_block("peak_carrier_allocator",
              gr::io_signature::make(1, 1, sizeof(int)),
              gr::io_signature::make(1, 1, sizeof(gr_complex)*64), len_tag_key),
        d_log(log)
    {
    	set_tag_propagation_policy(TPP_DONT);
    	set_relative_rate(1);
    }

    /*
     * Our virtual destructor.
     */
    peak_carrier_allocator_impl::~peak_carrier_allocator_impl()
    {
    }

    int
    peak_carrier_allocator_impl::work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
        const int *in = (const int *) input_items[0];
        gr_complex *out = (gr_complex *) output_items[0];
        std::vector<tag_t> tags;
        get_tags_in_range(tags, 0, nitems_read(0), nitems_read(0)+ninput_items[0]);
        for(unsigned t = 0; t < tags.size(); t++) {
	        add_item_tag(0, nitems_written(0), tags[t].key, tags[t].value);
        }
        
        mylog(boost::format("[peak_carrier_allocator_impl.cc] sub-carrier %1%") % in[0]);
        memset((void *) out, 0x00, sizeof(gr_complex)*64*noutput_items);
        out[in[0]] = gr_complex(1,0);

        return 1;
    }

  } /* namespace ieeebroadcast */
} /* namespace gr */

