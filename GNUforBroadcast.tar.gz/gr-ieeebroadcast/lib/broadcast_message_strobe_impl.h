/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifndef INCLUDED_IEEEBROADCAST_BROADCAST_MESSAGE_STROBE_IMPL_H
#define INCLUDED_IEEEBROADCAST_BROADCAST_MESSAGE_STROBE_IMPL_H

#include <ieeebroadcast/broadcast_message_strobe.h>

namespace gr {
  namespace ieeebroadcast {

    class broadcast_message_strobe_impl : public broadcast_message_strobe
    {
     private:
      uint16_t d_seq_nr;
      uint8_t d_src_mac[6];
      uint8_t d_dst_mac[6];
      uint8_t d_bss_mac[6];
      uint8_t d_psdu[1528];
      
      pmt::pmt_t d_msg;
      bool d_log;

     public:
      broadcast_message_strobe_impl(std::vector<uint8_t> src_mac,
      					std::vector<uint8_t> dst_mac,
      					std::vector<uint8_t> bss_mac,
      					pmt::pmt_t msg, bool log);
      ~broadcast_message_strobe_impl();
      
      void set_msg(pmt::pmt_t msg) {d_msg = msg;}
      pmt::pmt_t msg() const {return d_msg;}

      void carrier_in(pmt::pmt_t msg);
      
      bool check_mac(std::vector<uint8_t> mac);
      void generate_mac_data_frame(const char *msdu, int msdu_size, int *psdu_size);
    };

  } // namespace ieeebroadcast
} // namespace gr

#endif /* INCLUDED_IEEEBROADCAST_BROADCAST_MESSAGE_STROBE_IMPL_H */

