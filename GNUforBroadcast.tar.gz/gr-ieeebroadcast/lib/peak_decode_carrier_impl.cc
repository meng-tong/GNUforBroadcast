/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "peak_decode_carrier_impl.h"

#include "utils.h"
#include <volk/volk.h>

namespace gr {
  namespace ieeebroadcast {

    peak_decode_carrier::sptr
    peak_decode_carrier::make(int interval, bool log)
    {
      return gnuradio::get_initial_sptr
        (new peak_decode_carrier_impl(interval, log));
    }

    peak_decode_carrier_impl::peak_decode_carrier_impl(int interval, bool log)
      : gr::block("peak_decode_carrier",
              gr::io_signature::make(1, 1, sizeof(gr_complex)*64),
              gr::io_signature::make(0, 0, 0)),
        d_interval(interval), d_symbol_count(0), d_log(log),
        d_sum(0), d_flag(false)
    {
    	message_port_register_out(pmt::mp("out"));
    	//set_tag_propagation_policy(block::TPP_DONT);
    	
    	d_mags = (float*)calloc(64, sizeof(float));
    	d_peak_flag = (int*)calloc(64, sizeof(int));
    }

    peak_decode_carrier_impl::~peak_decode_carrier_impl()
    {
    	free(d_mags);
    	free(d_peak_flag);
    }

    int
    peak_decode_carrier_impl::general_work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
        const gr_complex *in = (const gr_complex *) input_items[0];
        
        int i = 0;
        while(i < ninput_items[0]) {
        	volk_32fc_magnitude_32f_u(d_mags, in, 64);
        	
        	// determine sub-carrier peak
        	d_sum = 0;
        	for(int k=0;k<64;++k) {
        		d_sum += d_mags[k];
    		}
        	d_sum /= 64.0;
        	
        	//FIXME: better peak recognization mechanism
        	for(int k=0;k<64;++k) {
        		if(d_mags[k] > 0.0001 && d_mags[k] > 4*d_sum) {
        			//mylog(boost::format("Peak Sub-Carrier: %1%") % k);
        			d_peak_flag[k] += 1;
        			d_flag = true;
        		}
        	}
        	
        	if(d_flag) {
        		d_symbol_count += 1;
        		
        		if(d_symbol_count >= d_interval) {
        			d_flag = false;
        			d_symbol_count = 0;
        			
        			//FIXME: encoding determination mechanism
        			int encN = 0;
        			message_port_pub( pmt::mp("out"), pmt::from_long(encN) );
        			mylog(boost::format("[peak_decode_carrier_impl.cc] new encoding: %1%")
        					% encN);
					
					memset(d_peak_flag, 0, sizeof(int)*64);
        		}
        	}
        	
        	i++; in += 64;
        }

        consume_each (i);

        return 0;
    }

  } /* namespace ieeebroadcast */
} /* namespace gr */

