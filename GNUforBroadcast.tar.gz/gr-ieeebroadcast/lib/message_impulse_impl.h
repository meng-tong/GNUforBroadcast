/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifndef INCLUDED_IEEEBROADCAST_MESSAGE_IMPULSE_IMPL_H
#define INCLUDED_IEEEBROADCAST_MESSAGE_IMPULSE_IMPL_H

#include <ieeebroadcast/message_impulse.h>

namespace gr {
  namespace ieeebroadcast {

    class message_impulse_impl : public message_impulse
    {
     private:
      void run();
      
      int d_encoding;
      float d_interval;
      bool d_log;
      bool d_finished;
      boost::shared_ptr<gr::thread::thread> d_thread;
      gr::thread::mutex d_mutex;

     public:
      message_impulse_impl(float interval, bool log);
      ~message_impulse_impl();
      
      void set_encodingrate(pmt::pmt_t msg);

      bool start();
      bool stop();
    };

  } // namespace ieeebroadcast
} // namespace gr

#endif /* INCLUDED_IEEEBROADCAST_MESSAGE_IMPULSE_IMPL_H */

