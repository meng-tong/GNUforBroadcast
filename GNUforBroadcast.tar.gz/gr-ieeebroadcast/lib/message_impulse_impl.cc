/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "message_impulse_impl.h"

#include "utils.h"

namespace gr {
  namespace ieeebroadcast {

    message_impulse::sptr
    message_impulse::make(float interval, bool log)
    {
      return gnuradio::get_initial_sptr
        (new message_impulse_impl(interval, log));
    }

    message_impulse_impl::message_impulse_impl(float interval, bool log)
      : gr::block("message_impulse",
              gr::io_signature::make(0,0,0),
              gr::io_signature::make(0,0,0)),
        d_interval(interval), d_log(log), d_finished(false),
        d_encoding(0)
    {
    	message_port_register_out(pmt::mp("out"));
    	
    	message_port_register_in(pmt::mp("in"));
    	set_msg_handler(pmt::mp("in"),
				boost::bind(&message_impulse_impl::set_encodingrate, this, _1));
    }

    message_impulse_impl::~message_impulse_impl()
    {
    }
    
    bool
    message_impulse_impl::start() {
    	d_thread = boost::shared_ptr<gr::thread::thread>
    		(new gr::thread::thread(boost::bind(&message_impulse_impl::run, this)));
		
		return block::start();
    }
    
    bool
    message_impulse_impl::stop() {
    	mylog(boost::format("Message Impulse Stop"));
    	d_finished = true;
    	d_thread->interrupt();
    	d_thread->join();
    	
    	return block::stop();
    }
    
    void
    message_impulse_impl::run() {
    	int seqN = 0;
    	
    	while(!d_finished) {
    		boost::this_thread::sleep(boost::posix_time::milliseconds(d_interval));
    		if(d_finished) {return;}
    		
    		mylog(boost::format("--------------------------------"));
			mylog(boost::format("\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/"));
			mylog(boost::format("[message_impulse_impl.cc] Initial Message %1%") % seqN);
			seqN += 1;
			
			gr::thread::scoped_lock lock(d_mutex);
			message_port_pub( pmt::mp("out"), pmt::from_long(d_encoding) );
    	}
    	
    	/*for(int i=0;i<d_num;++i) {
			if(d_finished) {return;}
			
			mylog(boost::format("--------------------------------"));
			mylog(boost::format("\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/"));
			mylog(boost::format("[message_impulse_impl.cc] Initial Message %1%") % i);
			
			// start with encoding 0
			message_port_pub( pmt::mp("out"), pmt::from_long(0) );
			boost::this_thread::sleep(boost::posix_time::milliseconds(500));
    	}*/
    }
    
    void
    message_impulse_impl::set_encodingrate(pmt::pmt_t msg) {
    	int enc = pmt::to_long(msg);
    	
    	gr::thread::scoped_lock lock(d_mutex);
    	d_encoding = enc;
    }

  } /* namespace ieeebroadcast */
} /* namespace gr */

