/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "subcarrier_mapper_impl.h"

#include "utils.h"

namespace gr {
  namespace ieeebroadcast {

    subcarrier_mapper::sptr
    subcarrier_mapper::make(bool log)
    {
      return gnuradio::get_initial_sptr
        (new subcarrier_mapper_impl(log));
    }

    subcarrier_mapper_impl::subcarrier_mapper_impl(bool log)
      : gr::block("subcarrier_mapper",
              gr::io_signature::make(0, 0, 0),
              gr::io_signature::make(1, 1, sizeof(int))),
        d_log(log)
    {
    	message_port_register_in(pmt::mp("in"));
    }

    subcarrier_mapper_impl::~subcarrier_mapper_impl()
    {
    }

    int
    subcarrier_mapper_impl::general_work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
        unsigned int *out = (unsigned int*)output_items[0];
        
        pmt::pmt_t msg(delete_head_blocking(pmt::intern("in")));
        
        if(pmt::is_eof_object(msg)) {
        	std::cout << "Sub-Carrier Mapper: Exiting" << std::endl;
        	return -1;
        }
        
        pmt::pmt_t key = pmt::string_to_symbol("packet_len");
		pmt::pmt_t value = pmt::from_long(1);
		pmt::pmt_t srcid = pmt::string_to_symbol(alias());
		add_item_tag(0, nitems_written(0), key, value, srcid);
        
        out[0] = pmt::to_long(msg);
        mylog(boost::format("[subcarrier_mapper_impl.cc] sub-carrier %1%") % out[0]);

        return 1;
    }

  } /* namespace ieeebroadcast */
} /* namespace gr */

