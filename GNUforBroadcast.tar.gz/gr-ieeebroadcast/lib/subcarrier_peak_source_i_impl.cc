/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "subcarrier_peak_source_i_impl.h"
#include <gnuradio/io_signature.h>
#include <gnuradio/block_detail.h>

#include "utils.h"

using namespace gr::ieeebroadcast;

subcarrier_peak_source_i_impl::subcarrier_peak_source_i_impl(
			float interval, bool log) :
		block("subcarrier_peak_source_i",
				gr::io_signature::make(0,0,0),
				gr::io_signature::make(0,0,0)),
		d_rng(0),
		d_log(log),
		d_interval(interval),
		d_finished(false) {
	message_port_register_out(pmt::mp("out"));
}

subcarrier_peak_source_i_impl::~subcarrier_peak_source_i_impl() {
}

bool
subcarrier_peak_source_i_impl::start()
{
	d_thread = boost::shared_ptr<gr::thread::thread>
		(new gr::thread::thread(boost::bind(&subcarrier_peak_source_i_impl::run, this)));
	
	return block::start();
}

bool
subcarrier_peak_source_i_impl::stop() {
	d_finished = true;
	d_thread->interrupt();
	d_thread->join();
	
	return block::stop();
}

void
subcarrier_peak_source_i_impl::run() {
	while(!d_finished) {
		boost::this_thread::sleep(boost::posix_time::milliseconds(d_interval));
		if(d_finished) {
			return;
		}

		int scN = (int)(27.0 * ((d_rng.ran1() * 2.0) - 1.0));
	    while(scN==-21 || scN==-7 || scN==0 || scN==7 || scN==21) {
	    	scN = (int)(27.0 * ((d_rng.ran1() * 2.0) - 1.0));
	    }
	    scN += 32;
	    mylog(boost::format("[subcarrier_peak_source_i_impl.cc] subcarrier %1%") %
	    		scN);
		message_port_pub( pmt::mp("out"), pmt::from_long(scN) );
		//message_port_pub( pmt::mp("out"), pmt::intern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") );
	}
}

subcarrier_peak_source_i::sptr
subcarrier_peak_source_i::make(float interval, bool log) {
	return gnuradio::get_initial_sptr(new subcarrier_peak_source_i_impl(interval, log));
}

