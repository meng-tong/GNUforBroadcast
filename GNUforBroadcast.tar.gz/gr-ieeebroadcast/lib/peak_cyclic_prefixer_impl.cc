/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "peak_cyclic_prefixer_impl.h"

namespace gr {
  namespace ieeebroadcast {

    peak_cyclic_prefixer::sptr
    peak_cyclic_prefixer::make(const std::string &len_tag_key)
    {
      return gnuradio::get_initial_sptr
        (new peak_cyclic_prefixer_impl(len_tag_key));
    }

    peak_cyclic_prefixer_impl::peak_cyclic_prefixer_impl(const std::string &len_tag_key)
      : gr::tagged_stream_block("peak_cyclic_prefixer",
              gr::io_signature::make(1, 1, 64*sizeof(gr_complex)),
              gr::io_signature::make(1, 1, sizeof(gr_complex)),
              len_tag_key)
    {
    	set_relative_rate(160);
    	
    	if(len_tag_key.empty()) {
    		std::cout<<"empty len tag key"<<std::endl;
    		set_output_multiple(160);
    	} else {
    		set_tag_propagation_policy(TPP_DONT);
		}
    }

    peak_cyclic_prefixer_impl::~peak_cyclic_prefixer_impl()
    {
    }

    int
    peak_cyclic_prefixer_impl::calculate_output_stream_length(const gr_vector_int &ninput_items)
    {
        int nout = ninput_items[0] * 160;
        return nout;
    }

    int
    peak_cyclic_prefixer_impl::work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
        gr_complex *in = (gr_complex *) input_items[0];
        gr_complex *out = (gr_complex *) output_items[0];
        int symbols_to_read = 0;
        
        if (!d_length_tag_key_str.empty()) {
        	symbols_to_read = ninput_items[0];
        	noutput_items = symbols_to_read * 160;
        } else {
        	symbols_to_read = std::min(noutput_items / (int)160, ninput_items[0]);
        	noutput_items = symbols_to_read * 160;
        }
        
        for(int sym_idx=0; sym_idx<symbols_to_read; sym_idx++) {
        	memcpy((void *)(out+32), (void *)in, 64*sizeof(gr_complex));
        	memcpy((void *)(out+32+64), (void *)in, 64*sizeof(gr_complex));
        	memcpy((void *)out, (void *)(in+32), 32*sizeof(gr_complex));
        	
        	in += 64;
        	out += 160;
        }
        
        if(!d_length_tag_key_str.empty()) {
        	std::vector<tag_t> tags;
        	get_tags_in_range(tags, 0, nitems_read(0),
        				nitems_read(0)+symbols_to_read);
			for(unsigned i=0; i<tags.size(); i++) {
				tags[i].offset = ((tags[i].offset-nitems_read(0)) * 160) + nitems_written(0);
				add_item_tag(0, tags[i].offset, tags[i].key, tags[i].value);
			}
        } else {
        	consume_each(symbols_to_read);
        }
        
        return noutput_items;
    }

  } /* namespace ieeebroadcast */
} /* namespace gr */

