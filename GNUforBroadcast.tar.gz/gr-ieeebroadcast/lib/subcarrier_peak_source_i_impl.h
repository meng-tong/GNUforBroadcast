/* -*- c++ -*- */
/* 
 * Copyright 2016 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifndef INCLUDED_IEEEBROADCAST_SUBCARRIER_PEAK_SOURCE_I_IMPL_H
#define INCLUDED_IEEEBROADCAST_SUBCARRIER_PEAK_SOURCE_I_IMPL_H

#include <ieeebroadcast/subcarrier_peak_source_i.h>
#include <gnuradio/random.h>

namespace gr {
  namespace ieeebroadcast {

    class subcarrier_peak_source_i_impl : public subcarrier_peak_source_i
    {
     private:
       void run();
       
       gr::random d_rng;
       bool d_log;
       float d_interval;
       bool d_finished;
       boost::shared_ptr<gr::thread::thread> d_thread;

     public:
      subcarrier_peak_source_i_impl(float interval, bool log);
      ~subcarrier_peak_source_i_impl();

      void set_delay(float delay) {d_interval = delay;}
      float get_delay() const {return d_interval;}
      
      bool start();
      bool stop();
    };

  } // namespace ieeebroadcast
} // namespace gr

#endif /* INCLUDED_IEEEBROADCAST_SUBCARRIER_PEAK_SOURCE_I_IMPL_H */

